#include<stdio.h>
int main()
{
int month,year,days,diff,t=1,n;
int day[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
int a,b,i,j;
printf("Month and year:");
scanf("%d%d",&month,&year);
if((year%4==0 && year%100!=0) || (year%400==0))
day[2]=29;
diff=year-1904;
a=diff/4;
b=diff-a;
days=366*a+365*b;
for(i=1;i<month;i++)
{
	days=days+day[i];
}
n=days%7;
switch(month)
{
	case 1:
	printf("January\n");
	break;
	 case 2:
        printf("February\n");
        break;
	 case 3:
        printf("March\n");
        break;
	 case 4:
        printf("April\n");
        break;
	 case 5:
        printf("May\n");
        break;
	 case 6:
        printf("June\n");
        break;
	 case 7:
        printf("July\n");
        break;
	 case 8:
        printf("August\n");
        break;
	 case 9:
        printf("September\n");
        break;
	 case 10:
        printf("October\n");
        break;
	 case 11:
        printf("November\n");
        break;
	 case 12:
        printf("December\n");
        break;
}
printf("%d\n",year);
printf("Sun\tMon\tTue\tWed\tThurs\tFri\tSat\n");

printf("\n");

for(i=1;i<=7;i++)
{
	if(i<n)	
	printf(" \t");
	else 
	{
	printf("%d\t",t);
	t++;
	}
}
printf("\n");
for(i=1;i<=5;i++)
{
	for(j=1;j<=7;j++)
{
	if(t<=day[month])
	printf("%d\t",t++);
	
}
printf("\n");
}
return 0;
}



