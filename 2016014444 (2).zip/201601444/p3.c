#include<stdio.h>
int main()
{  char str[100];
   int i;
   printf("Enter a string:");
   scanf("%s",&str);
   for(i=0;str[i]!='\0';i++)
   {  if((str[i]=='A'||str[i]=='E'||str[i]=='I'||str[i]=='O'||str[i]=='U'||str[i]=='a'||str[i]=='e'||str[i]=='i'||str[i]=='o'||str[i]=='u')&&(str[i+1]=='A'||str[i+1]=='E'||str[i+1]=='I'||str[i+1]=='O'||str[i+1]=='U'||str[i+1]=='a'||str[i+1]=='e'||str[i+1]=='i'||str[i+1]=='o'||str[i+1]=='u'))

   {  printf("%c%c,",str[i],str[i+1]);}
   }
   return 0;
}







