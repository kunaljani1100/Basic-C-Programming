#include<stdio.h>
int main()
{
int i=0,j=0,a,b;

for(a=0;;a++)
	{
	printf("enter '1' for first class \n enter '2' for economy class \n if you want to exit then enter '3' ");
	scanf("%d",&b);
	if(b==3)
	break;

	if(b==1 && i<5)
	{
	i++;
	printf("your seat is %d \n",i);
	}
	 else if(b==1 && i>=5)
	{
	  printf("sorry,there are no seat available in first class \n if you want to if you want to continue then press eny key \n if you want to exit then enter '3'\n next flight leaves in 3 hours");
 	scanf("%d",&b);
	 if(b==3)
	break;
	}
	else if(b==2 && j<5)
	{
	j++;
	printf("your seat is %d \n",j);
	}
	 else if(b==2 && i>=5)
        {
        printf("sorry,there are no seat available in economy class \n next flight leaves in 3 hours");}
        else
  	printf("you entered wrong number \n");
	
} 	
return 0;
}
  
