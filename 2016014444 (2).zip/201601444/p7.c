#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
int seed=0,i=0,j;
seed=time(NULL);
srand(seed);
char word1[15],word2[15];
while(i<=10)
{
   word1[i]=(rand()%'z'+'a');
   ++i;
}
for(j=0;j<=10;j++)
{  word2[j]=word1[i];
   i--;
}
printf("%s",word2);
return 0;
}

