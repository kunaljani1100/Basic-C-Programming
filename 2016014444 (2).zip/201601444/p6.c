#include<stdio.h>
#include<string.h>
int main()
{
char nor[5][20],temp;		
int i,j;
printf("enter five string: ");
for(i=0;i<5;i++);
{
  for(j=0;j<20;j++)
	{
	scanf("%c",&nor[i][j]);
	}

}
for(i=0;i<5;i++)
	{
	for(j=0;j<5;j++)
	{
	temp=nor[i][j];
	nor[i][j]=nor[i][5-j];
	nor[i][5-j]=temp;
	}
	}
for(i=0;i<5;i++)
{
printf("\n %s",nor[i]);
}
return 0;
}


     
 
   
