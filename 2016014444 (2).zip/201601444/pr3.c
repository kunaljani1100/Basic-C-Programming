#include<stdio.h>
#include<string.h>
int main()
{  char str[6][20],tmp[20];
   int i,j,k;
   printf("Enter 6 strings:");
   for(i=0;i<6;i++)
   {  scanf("%s",str[i]);
   }
   for(i=0;i<3;i++)
   {  for(j=0;j<2;j++)
      if(str[j][0]>str[j+1][0])
      {  strcpy(tmp,str[j]);
         strcpy(str[j],str[j+1]);
         strcpy(str[j+1],tmp);
      }
   }
   for(i=0;i<3;i++)
   {  printf("%s\n",str[i]);
   }
   for(i=3;i<5;i++)
   {  for(j=3;j<5;j++)
      if(str[j][0]>str[j+1][0])
      {  strcpy(tmp,str[j]);
         strcpy(str[j],str[j+1]);
         strcpy(str[j+1],tmp);
      }
   }
   for(i=3;i<5;i++)
   {  printf("%s\n",str[i]);
   }
   return 0;
}
