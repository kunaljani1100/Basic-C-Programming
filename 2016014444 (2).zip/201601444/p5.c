#include<stdio.h>
#include<string.h>
int main()
{
    int n,i,j,l;
    char name[5][20],str[5][20];
    printf("enter five string:");
    for(i=0;i<5;i++){
       gets(name[i]);
     }
    for(i=0;i<4;i++)
       {
	for(j=0;j<4;j++)
	{
       l=strlen(name[j+1]);
	n=strlen(name[j]);
	if(l<n)
	{
        strcpy(str,name[j+1]);
        strcpy(name[j+1],name[j]);
	strcpy(name[j],str);
        }
	}
      }	     
for(i=0;i<5;i++)
{
printf("\n %s",name[i]);
}
return 0;
}
             
         
 
   
