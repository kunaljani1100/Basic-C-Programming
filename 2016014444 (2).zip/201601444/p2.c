#include<stdio.h>
int main()
{  int dd,year,mm;
   char month[20];
   printf("Enter year and day:");  
   scanf("%d%d",&year,&dd);
   printf("Enter month:");
   scanf("%s",&month);
   if(strcmp(month,"January")==0)
   mm=1;
   else if(strcmp(month,"February")==0)
   mm=2;
   else if(strcmp(month,"March")==0)
   mm=3;
   else if(strcmp(month,"April")==0)
   mm=4;
   else if(strcmp(month,"May")==0)
   mm=5;
   else if(strcmp(month,"June")==0)
   mm=6;
   else if(strcmp(month,"July")==0)
   mm=7;
   else if(strcmp(month,"August")==0)
   mm=8;
   else if(strcmp(month,"September")==0)
   mm=9;
   else if(strcmp(month,"October")==0)
   mm=10;
   else if(strcmp(month,"November")==0)
   mm=11;
   else if(strcmp(month,"December")==0)
   mm=12; 
   printf("%d/%d/%d",dd,mm,year);
   return 0;
}

