#include<stdio.h>
int main()
{  int i=0;
   char ch;
   while(i<256)
   {  ch=i;
      printf("%d:%c",i,ch);
      i++;
   }
   return 0;
}
