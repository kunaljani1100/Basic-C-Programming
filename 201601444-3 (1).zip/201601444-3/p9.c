#include<stdio.h>
int main()
{  int lev,i=0,j=1,k=1;
   printf("How many levels?");
   scanf("%d",&lev);
   while(i<lev+1)
   {  printf("%d ",0);
      i++;
   }
   printf("\n");
   i=0;
   while(j<lev+1)
   {  while(i<j)
      {  printf("%d ",k);
         k++;
         i++;
      }
      while(i<lev+1)
      {  printf("%d ",0);
         i++;
      }
      printf("\n");
      i=0;
      j++;
   }
   return 0;
}
      
