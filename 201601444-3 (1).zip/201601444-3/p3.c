#include<stdio.h>
int main()
{  int pno;
   float price,total,qty;
   printf("Enter product no:");
   scanf("%d",&pno);
   switch(pno)
   {  case 1:
      price=29.5;
      break;
      case 2:
      price=45;
      break;
      case 3:
      price=48;
      break;
      case 4:
      price=95.5;
      break;
      case 5:
      price=59.5;
      break;
      case 6:
      price=22.5;
      break;  
      default:
      printf("Product not available:");
      break;
   }
   printf("Enter quantity:");
   scanf("%f",&qty);
   total=price*qty;
   printf("Total=%f",total);
   return 0;
}
   
        
