#include<stdio.h>
int main()
{  int num,flag=1,i=1;
   printf("Enter a number:");
   scanf("%d",&num);
   while(num!=1)
   {  if(num%i!=0) 
      {  flag=0;
         break;
      }
      else
      {  num=num/i;
      }
      i++;
   }
   switch(flag)
   {  case 1:
      printf("Yes"); 
      break;
      case 0:
      printf("No");
      break;
   } 
   return 0;
}
