#include<stdio.h>
int main()
{  int a,b,c,i=0;
   printf("Enter 3 integers:");
   scanf("%d %d %d",&a,&b,&c);
   while(i<a)
   {  printf("*");
      i++;
   }
   i=0;
   while(i<b)
   {  printf("$");
      i++;
   }
   i=0;
   while(i<c);
   {  printf("@");
      i++;
   }
   return 0;
}
