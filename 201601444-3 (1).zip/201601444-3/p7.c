#include<stdio.h>
int main()
{  int a,b,c=1,i=1;
   printf("enter integer 1:");
   scanf("%d",&a);
   printf("enter integer 2:");
   scanf("%d",&b);
   if(a<b)
   {  while(i<=b)
      {  c=c*a;
         i++;
      }
   }
   else
   {  while(i<=a)
      {  c=c*b;
         i++;
      }
   }
   printf("%d",c);
   return 0;
}

