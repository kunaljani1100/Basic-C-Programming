#include<stdio.h>
int main()
{  char ch;
   int i;
   printf("Enter a character:");
   scanf("%c",&ch);
   if(ch>='A'&&ch<='Z'||ch>='a'&&ch<='z')
   {  switch(ch)
      {  case 'A':
         printf("vowel");
         break;
         case 'E':
         printf("vowel");
         break;
         case 'I':
         printf("vowel");
         break;
         case 'O':
         printf("vowel");
         break;
         case 'U':
         printf("vowel");
         break;
         case 'a':
         printf("vowel");
         break;
         case 'e':
         printf("vowel");
         break;
         case 'i':
         printf("vowel");
         break;
         case 'o':
         printf("vowel");
         break;
         case 'u':
         printf("vowel");
         break;
         default:
         printf("consonant");
         break;
      }
   }
   if(ch>='0'&&ch<='9')
   {  i=1;
      switch(i)
      {  case 1:
         printf("number");
         break;
         default:
         printf("other");
         break;
      }
   }
   return 0;
}

