#include<stdio.h>
int main()
{  float num,sqrt;
   float i=1,j=1;
   printf("Enter a number:");
   scanf("%f",&num);
   while(i*i<num)
   {  i=i+0.0001;
   }
   printf("%.4f",i);
   return 0;   
}  

