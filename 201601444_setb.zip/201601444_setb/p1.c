#include<stdio.h>
int main()
{  char s[100];
   int len;
   printf("Enter the string length:(1 to 100)");
   scanf("%d",&len);
   printf("Enter the string:");
   scanf("%s",s);
   int i,j,cnt=0;
   for(i=0;i<len;i++)
   {  for(j=i+1;j<len;j++)
      {  if(s[i]!=s[j])
         {  
            break;
         }
         else
         cnt++;
      }
      for(;j<len;j++)
      {  s[j-cnt]=s[j];
      }
      len=len-cnt;
      cnt=0;
   }
   s[i]='\0';
   if(len==1)
   {  printf("Empty String.");}
   else
   {
   printf("%s",s);
   }
   return 0;
}
