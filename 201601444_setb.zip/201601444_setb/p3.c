#include<stdio.h>
int power(int m,int n)
{  int i;
   int res=1;
   for(i=0;i<n;i++)
   res=res*m;
   return res;
}
void reversebits(int n)
{  unsigned int m,j,andmask,k;
   int i;
   for(i=0;power(2,i)<n;i++);
   for(j=0;j<=i;j++)
   {  m=j;
      andmask=1<<j;
      k=n&andmask;
      if(k==0)
      printf("0");
      else 
      printf("1");
   }
}
int main()
{  unsigned int num,k,andmask,j;
   int i;
   printf("Enter the number:");
   scanf("%d",&num);
   printf("Before:");
   for(i=0;power(2,i)<num;i++);
   for(;i>=0;i--)
   {  j=i;
      andmask=1<<j;
      k=num&andmask;
      if(k==0)
      printf("0");
      else
      printf("1");
   }
   printf("\nAfter:");
   reversebits(num);
   return 0;
}
