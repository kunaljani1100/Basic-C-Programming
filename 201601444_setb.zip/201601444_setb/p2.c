#include<stdio.h>
int main()
{  FILE *fp;
   fp=fopen("file.txt","r");
   char str[30],ch;
   int i,j,k=0,flag=1;
   char name[30],father[30],child[30];
   printf("Enter name:");
   scanf("%s",name);
   int grandchildren=0;
   while(ch!=EOF)
   {  while(ch!=' ')
      ch=fgetc(fp);
      while(ch!='\n')
      {  ch=fgetc(fp);
         father[k++]=ch;
      }
      father[k]='\0';
      for(i=0;father[i]!='\0';i++)
      {  if(father[i]!=name[i])
         {  flag=0;}
      }
      if(flag==1)
      break;
      if(ch==EOF)
      break;
   }
   fclose(fp);
   fp=fopen("file.txt","r");
   k=0;
   while(ch!=EOF)
   {  flag=1;
      while(ch!=' ')
      {  ch=fgetc(fp);
         child[k++]=ch;
      }
      while(ch!='\n')
      {  ch=fgetc(fp);
         if(ch!=father[k++])
         {  flag=0;}
      }
      if(flag==1)
      break;
      if(ch==EOF)
      break;
   }
   fclose(fp);
   fp=fopen("file.txt","r");
   k=0;
   while(ch!=EOF)
   {  flag=1;
      while(ch!=' ')
      ch=fgetc(fp);
      while(ch!='\n')
      {  ch=fgetc(fp);
         if(child[k++]!=ch)
         {  flag=0;
            break;
         }
      }
      if(flag==1)
      grandchildren++;
      if(ch==EOF)
      break;
   }
   printf("%d",grandchildren);
   fclose(fp);
   return 0;
}
      
   
