#include<stdio.h>
int main()
{  int num[41],a,i,j;
   for(i=1;i<=40;i++)
   {  num[i]=i;
   }
   for(i=2;i<=40;i++)
   {  for(j=i*2;j<=40;j=j+i)
      num[j]=0;
   }
   for(i=2;i<=40;i++)
   {  if(num[i]!=0)
      printf("%d ",num[i]);
   }
   return 0;
}
