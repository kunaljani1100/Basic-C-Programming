#include<stdio.h>
int main()
{  int count=0,i=0;
   char str[100];
   printf("Enter a string");
   scanf("%s",&str);
   while(str[i]!='\0')
   {  switch(str[i])
      {  case 'A':
         break;
         case 'E':
         break;
         case 'I':
         break;
         case 'O':
         break;
         case 'U':
         break;
         case 'a':
         break;
         case 'e':
         break;
         case 'i':
         break;
         case 'o':
         break;
         case 'u':
         break;
         default:
         count++;
      }
      i++;
   }
   printf("%d",count-1);
   return 0;
}

