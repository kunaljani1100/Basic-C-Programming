#include<stdio.h>
int main()
{  char str1[100],str2[100],flag=1,i=0,j=0;
   printf("Enter way shop read by person 1:");
   scanf("%s",&str1);
   printf("Enter way shop read by person 2:");
   scanf("%s",&str2);
   while(str1[i]!='\0')
   {  i++;
   } 
   while(str2[j]!='\0')
   {  j++;
   }
   if(i!=j)
   {  flag=0;
   }
   else
   {  while(str1[i]!='\0')
      {  if(str1[i]!=str2[i])
         {  flag=0;}
      }
   }
   if(flag==1)
   {  printf("YES");
   }
   else
   {  printf("NO");
   }
   return 0; 
}
