#include<stdio.h>
int main()
{  int a[2][2],i,j,d;
   printf("Enter a matrix:");
   for(i=0;i<2;i++)
   {  for(j=0;j<2;j++)
      {  scanf("%d",&a[i][j]);
      }
   }
   d=a[0][0]*a[1][1]-a[1][0]*a[0][1];
   printf("%d",d);
   return 0;
}
