#include<stdio.h>
int main()
{  int a[6][6],max,i,j;
   printf("Enter a matrix:");
   for(i=0;i<6;i++)
   {  for(j=0;j<6;j++)
      {  scanf("%d",&a[i][j]);
      }
   }
   max=a[0][0];
   for(i=0;i<6;i++)
   {  for(j=0;j<6;j++)
      {  if(a[i][j]>max)
         max=a[i][j];
      }
   }
   printf("%d",max);
   return 0;
}
