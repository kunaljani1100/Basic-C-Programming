#include<stdio.h>
int main()
{  int ary[10],flag,i=0,j=0;
   printf("Enter 10 elements:");
   while(i<10)
   {
       scanf("%d",&ary[i]);
       i++;
   }
   for(i=0;i<10;i++)
   { flag=1;
     for(j=0;j<10;j++)
     {  if(ary[i]==ary[j]&&i!=j)
        {  flag=0;
        }
     }
        if(flag==1)
        {  printf("%d ",ary[i]);
        }
     
   }
   return 0;
}

