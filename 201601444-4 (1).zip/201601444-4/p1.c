#include<stdio.h>
int main()
{  char str[100],str2[100],j=0,i=0;
   printf("Enter any string:");
   scanf("%s",&str);
   while(str[i]!='\0')
   {   switch(str[i])
       {  case 'A':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break;
          case 'E':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break;
          case 'I':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break;
          case 'O':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break;
          case 'U':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break;
          case 'a':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break;
          case 'e':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break;
          case 'i':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break;
          case 'o':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break;
          case 'u':
          str2[j]=str[i];
          str[i]='0';
          j++;
          break; 
       }
       i++;
   }
   i=0;
   while(str[i]!='\0') 
   {   if(str[i]!='0')
       {  str2[j]=str[i];
          j++;
       } 
       i++;
   }
   for(i=0;str[i]!='\0';i++)
   {   str[i]=str2[i];
   }
   printf("%s",str);
   return 0;
}

  
