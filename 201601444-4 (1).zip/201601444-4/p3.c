#include<stdio.h>
int main()
{  int a[15]={2,4,54,61,5,6,1,3,45,21,35,64,12,9,11};
   int num,flag=0,i=0;
   printf("Enter a number:");
   scanf("%d",&num);
   while(i<15)
   {  if(a[i]==num)
      {  flag=1;
      }
      i++;
   }
   if(flag==0)
   {  printf("No");
   }
   else
   {  printf("Yes");
   }
   return 0;
}
   
