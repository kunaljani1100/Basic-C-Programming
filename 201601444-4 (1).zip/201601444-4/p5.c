#include<stdio.h>
int main()
{  int a[10],i=0,j=0,tmp;
   printf("Enter 10 elements:");
   for(i=0;i<10;i++)
   {  scanf("%d",&a[i]);
   }
   for(i=0;i<10;i++)
   {  for(j=0;j<9;j++)
      {  if(a[j]>a[j+1])
         {  tmp=a[j];
            a[j]=a[j+1];
            a[j+1]=tmp;
         }
      }
   }
   for(i=0;i<10;i++)
   {  printf("%d ",a[i]);
   }
   return 0;
}
