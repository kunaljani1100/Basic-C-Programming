#include<stdio.h>
struct date
{  int dt;
   int month;
   int year;
};
struct employee
{  int code;
   char name[20];
   struct date dj;
}e[5];
int main()
{  struct date dc;
   int i;
   for(i=0;i<5;i++)
   {  printf("Enter code:");
      scanf("%d",&e[i].code);
      printf("Enter name:");
      scanf("%s",&e[i].name);
      printf("Enter date of joining:");
      scanf("%d%d%d",&e[i].dj.dt,&e[i].dj.month,&e[i].dj.year);
   }
   printf("Enter current date:");
   scanf("%d%d%d",&dc.dt,&dc.month,&dc.year);
   for(i=0;i<5;i++)
   {  if(dc.year-e[i].dj.year==3)
      {  if(dc.month>e[i].dj.month)
	 {  printf("Code:");
            printf("%d\n",e[i].code);
	    printf("Name:");
	    printf("%s\n",e[i].name);
            printf("Date of joining:");
	    printf("%d/%d/%d\n",e[i].dj.dt,e[i].dj.month,e[i].dj.year);
	 }
	 else if(dc.month==e[i].dj.month&&dc.dt>e[i].dj.dt)
         {  printf("Code:");
            printf("%d\n",e[i].code);
	    printf("Name:");
	    printf("%s\n",e[i].name);
	    printf("Date of joining:");
	    printf("%d/%d/%d\n",e[i].dj.dt,e[i].dj.month,e[i].dj.year);
	 }
      }
      if(dc.year-e[i].dj.year>3)
      {   printf("Code:");
	  printf("%d\n",e[i].code);
	  printf("Name:");
	  printf("%s\n",e[i].name);
	  printf("Date of joining:");
	  printf("%d/%d/%d\n",e[i].dj.dt,e[i].dj.month,e[i].dj.year);
      }
      printf("\n\n\n");
   }
   return 0;
}

