#include<stdio.h>
#include<stdlib.h>

void firstnode();
void midnode(int);
void endnode();
void display();
struct node{
	int element;
	struct node* nextp;
};
struct node *start=NULL;
int n=0;

void main()
{	
	int n=0;
	printf("Choose one of the following:\n1.Add first node\n2.Add a node in the middle of the linked list\n3.Add an end node\n4.Display all the current nodes\n5.Exit\nChoice: ");
	int choice;
	scanf("%d",&choice);
	while(choice==1||choice==2||choice==3||choice==4){
		if(choice==1){
			firstnode();
			n++;
		}
		if(choice==2){
			printf("After which position do you want to add the node\nPosition: ");
			int pos;
			scanf("%d",&pos);
			midnode(pos);
			n++;
		}
		if(choice==3){
			n++;
			endnode();
		}
		if(choice==4)
			display();
		if(choice ==5)
			break;
		printf("Choose one of the following:\n1.Add first node\n2.Add a node in the middle of the linked list\n3.Add an end node\n4.Display all the current nodes\n5.Exit\nChoice: ");
		scanf("%d",&choice);
	}
}

void firstnode()
{	
	struct node *p;
	p= (struct node *)malloc(sizeof(struct node));
	if(start!=NULL){
		p->nextp=start;
		start=p;
	}else{
	start=p;
	p->nextp=NULL;
	}
	printf("Enter the value to be stored in this node:\nValue: ");
	scanf("%d",&(p->element));
}
void midnode(int pos)
{
	struct node *p;
	struct node *nav=start;
	int i;
	p= (struct node* )malloc(sizeof(struct node));
	for(i=1;i<pos;i++){
		nav=nav->nextp;
	}		 
	printf("Enter the value to be stored in this node:\nValue: ");
	scanf("%d",&(p->element));
	p->nextp=nav->nextp;
	nav->nextp=p;
}
void endnode()
{
	struct node *p;
	p=(struct node *)malloc(sizeof(struct node ));
	struct node *nav=start;
	int i;
	for(;nav->nextp!=NULL;){
		nav=nav->nextp;
	}
	nav->nextp=p;
	printf("Enter the value to be stored in this node:\nValue: ");
	scanf("%d",&(p->element));
	p->nextp=NULL;
}
void display()
{
	int i;
	struct node *nav=start;
	for(i=1;;i++,nav=nav->nextp){
		printf("Node %d: %d\n",i,nav->element);
		if(nav->nextp==NULL)
			break;
	}
}



