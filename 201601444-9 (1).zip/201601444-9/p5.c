#include<stdio.h>
union a
{  char c;
   short int s;
   int i;
   long int b;
};
int main()
{ 
   union a k;
   printf("Enter values:");
   scanf("%c%d%d%ld",&k.c,&k.s,&k.i,&k.b);
   printf("%d %d %d %d",k.c,k.s,k.i,k.b);
   return 0;
}
