#include<stdio.h>
int main()
{  unsigned int num,cnt=0;
   printf("Enter the number:");
   scanf("%d",&num);
   int i;
   unsigned char j,k,andmask;
   for(i=7;i>=0;i--)
   {  j=i;
      andmask=1<<j;
      k=num&andmask;
      if(k!=0)cnt++;
   }
   printf("%d",cnt);
   return 0;
}

