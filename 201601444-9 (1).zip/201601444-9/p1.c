#include<stdio.h>
struct date
{  int dt;
   int month;
   int year;
}d1,d2;
int main()
{  printf("Enter date 1:");
   scanf("%d%d%d",&d1.dt,&d1.month,&d1.year);
   printf("Enter date 2:");
   scanf("%d%d%d",&d2.dt,&d2.month,&d2.year);
   if(d1.dt==d2.dt&&d1.month==d2.month&&d1.year==d2.year)
   {  printf("Equal.");
   }
   else
   {  printf("Unequal.");
   }
   return 0;
}

