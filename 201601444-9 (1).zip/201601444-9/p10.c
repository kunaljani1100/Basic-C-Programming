#include<stdio.h>
int main()
{  unsigned char num,j,k,andmask,l;
   int i,pow=0,flag=1;
   printf("Enter any number:");
   scanf("%d",&num);
   for(i=2;i<num;i=i*2)
   {  pow++;}
   for(i=7;i>=0;i--)
   {  j=i;
      andmask=1<<j;
      k=num&andmask;
      if(i!=7-pow&&k!=0)
      flag=0;
   }
   if(flag==0)
   {  printf("NO");
   }
   else
   {  printf("YES");
   }
   return 0;
}


