#include<stdio.h>
#include<string.h>
struct library
{  int acno;
   char title[20];
   char aname[20];
   float price;
   int flag;
}l[5];
int main()
{  int ch,cnt=0,i,j,acn,tmp;
   char anam[20];
   while(ch!=7){
   printf("Enter your choice:\n");
   printf("1.Add\n");
   printf("2.Display\n");
   printf("3.List author books\n");
   printf("4.List title\n");
   printf("5.List count\n");
   printf("6.Order by accession no\n");
   printf("7.Exit");
   scanf("%d",&ch);
   switch(ch)
   {  case 1:
	if(cnt==4)
	{  printf("No new books");	
        break;}
	printf("Enter accession no:");
	scanf("%d",&l[cnt].acno);
	printf("Enter title:");
	scanf("%s",l[cnt].title);
	printf("Enter author name:");
	scanf("%s",l[cnt].aname);
	printf("Enter price:");
	scanf("%f",&l[cnt].price);
	printf("Issue status(0 or 1)");
	scanf("%d",&l[cnt].flag);
	cnt++;
        break;   
      case 2:   
	for(i=0;i<cnt;i++)
	{  printf("Acno:%d\n",l[i].acno);	
	   printf("Title:%s\n",l[i].title);
	   printf("Author name:%s\n",l[i].aname);
           printf("Price:%f\n",l[i].price);
	}
	printf("\n");
	break;
      case 3:
	printf("Enter author name:");
        scanf("%s",anam);
        for(i=0;i<cnt;i++)
        {  if(strcmp(anam,l[i].aname)==0)
	   printf("%s\n",l[i].title);
	}
        break;
      case 4:
	printf("Enter accession number:");
	scanf("%d",&acn);
        for(i=0;i<cnt;i++)
	{  if(l[i].acno==acn)
	   printf("%s",l[i].title);
	}
	break;
      case 5:
        printf("No of books:%d",cnt);
	break;
      case 6:
        for(i=0;i<cnt;i++)
        {  for(j=0;j<cnt-1;j++)
	   {   if(l[j].acno<l[j+1].acno)
	       {  tmp=l[j].acno;
		  l[j].acno=l[j+1].acno;
		  l[j+1].acno=tmp;
	       }
	   }
	}
	for(i=0;i<cnt;i++)
        {  printf("%s\n",l[i].title);
	}
      case 7:
	break;
   }}
   return 0;
}
   

