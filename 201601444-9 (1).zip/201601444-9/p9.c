#include<stdio.h>
int main()
{  int game;
   printf("Enter any number:");
   scanf("%d",&game);
   int i,cnt=0;
   unsigned char j,k,andmask;
   for(i=7;i>=0;i--)
   {  j=i;
      andmask=1<<j;
      k=game&andmask;
      if(k!=0)
      {  if(i==7)
	 {  printf("Chess\n");}
	 if(i==6)
         {  printf("Carrom\n");}
	 if(i==5)
	 {  printf("Table Tennis\n");}
	 if(i==4)
         {  printf("Lawn Tennis\n");}
	 if(i==3)
         {  printf("Hockey\n");}
	 if(i==2)
         {  printf("Football\n");}
	 if(i==1)
	 {  printf("Basketball\n");}
	 if(i==0)
	 {  printf("Cricket\n");}
         cnt++;
      }
   }
      if(cnt>=5)
      {  printf("Won the cup.");}
      else
      {  printf("Lost the cup.");}
      return 0;
}
