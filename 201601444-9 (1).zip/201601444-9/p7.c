#include<stdio.h>
int main()
{  enum days
   {  Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday
   };
   int d;
   printf("Enter a number from 0 to 6:");
   scanf("%d",&d);
   if(d==Sunday||d==Saturday)
   {  printf("Its weekend.");
   }
   else
   {  printf("Its not the weekend.");
   }
   return 0;
}
