#include<stdio.h>
void modify(int a[],int size)
{  int i;
   for(i=0;i<size;i++)
   {  a[i]=a[i]*3;
   }
}
int main()
{  int ary[10],i;
   printf("Enter 10 elements:");
   for(i=0;i<10;i++)
   {  scanf("%d",&ary[i]);
   }
   modify(ary,10);
   for(i=0;i<10;i++)
   {  printf("%d\n",ary[i]);
   }
   return 0;
}
