#include<stdio.h>
#include<string.h>
void prlen(char str[5][20],int size)
{  int i,j;
   char tmp[20];
   for(j=0;j<size;j++){
   for(i=0;i<size;i++)
   {  if(strlen(str[i+1])<strlen(str[i]))
      {  strcpy(tmp,str[i]);
         strcpy(str[i],str[i+1]);
         strcpy(str[i+1],tmp);
      }}
   }
   for(i=0;i<size;i++)
   {  printf("%s\n",str[i]);}
}
int main()
{  char str[5][20];
   int i;
   printf("Enter 5 strings:");
   for(i=0;i<5;i++)
   {  scanf("%s",str[i]);
   }
   prlen(str,5);
   return 0;
}

