#include<stdio.h>
void swap(int *a,int *b,int *c)
{  int tmp;  
   tmp=*c;
   *c=*b;
   *b=*a;
   *a=tmp;
   printf("a=%d,b=%d,c=%d",*a,*b,*c);
}
int main()
{  int a,b,c,*s,*q,*r;
   printf("Enter values of a,b,c:");
   scanf("%d%d%d",&a,&b,&c);
   s=&a;
   q=&b;
   r=&c;
   swap(s,q,r);
   return 0;
}
   
