#include<stdio.h>
#include<string.h>
int calc(char str[4][20],int size)
{  int d,sum=0,i;
   for(i=0;i<4;i++)
   {
   if(strcmp(str[i],"one")==0)
   {  d=1;
      sum=sum+1;
   }
   else if(strcmp(str[i],"two")==0)
   {  d=2;
      sum=sum+2;
   }
   else if(strcmp(str[i],"three")==0)
   {  d=3;
      sum=sum+3;
   }
   else if(strcmp(str[i],"four")==0)
   {  d=4;
      sum=sum+4;
   }
   else if(strcmp(str[i],"five")==0)
   {  d=5;
      sum=sum+5;
   }
   else if(strcmp(str[i],"six")==0)
   {  d=6;
      sum=sum+6;
   }
   else if(strcmp(str[i],"seven")==0)
   {  d=7;
      sum=sum+7;
   }
   else if(strcmp(str[i],"eight")==0)
   {  d=8;
      sum=sum+8;
   }
   else if(strcmp(str[i],"nine")==0)
   {  d=9;
      sum=sum+9;
   }
   else if(strcmp(str[i],"eleven")==0)
   {  d=11;
      sum=sum+11;
   }
   else if(strcmp(str[i],"twelve")==0)
   {  d=12;
      sum=sum+12;
   }
   else if(strcmp(str[i],"thirteen")==0)
   {  d=13;
      sum=sum+13;
   }
   else if(strcmp(str[i],"fourteen")==0)
   {  d=14;
      sum=sum+14;
   }
   else if(strcmp(str[i],"fifteen")==0)
   {  d=15;
      sum=sum+15;
   }
   else if(strcmp(str[i],"sixteen")==0)
   {  d=16;
      sum=sum+16;
   }
   else if(strcmp(str[i],"seventeen")==0)
   {  d=17;
      sum=sum+17;
   }
   else if(strcmp(str[i],"eighteen")==0)
   {  d=18;
      sum=sum+18;
   }
   else if(strcmp(str[i],"nineteen")==0)
   {  d=19;
      sum=sum+19;
   }
   else if(strcmp(str[i],"twenty")==0)
   {  d=20;
      sum=sum+20;
   }}
   return sum;
}
int main()
{  
   char str[4][20];
   int i;
   printf("Enter word nos from 1 to 20:");
   for(i=0;i<4;i++)
   { 
      scanf("%s",str[i]);
      printf("%d",calc(str,4));
   }
   return 0;
}
