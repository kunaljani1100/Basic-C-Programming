#include<stdio.h>
int main()
{  int n,*a,i,k,b[10];
   printf("Enter size:(less than 10)");
   scanf("%d",&n);
   k=malloc(n*sizeof(int));
   printf("Enter array:");
   for(i=0;i<n;i++)
   {  scanf("%d",&b[i]);
   }
   for(i=0;i<n;i++)
   {  printf("%d ",b[i]);
   }
   return 0;
}
