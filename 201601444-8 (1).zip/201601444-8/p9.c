#include<stdio.h>
int main()
{  char *str;
   int n;
   printf("Enter size:");
   scanf("%d",&n);
   str=malloc(n*sizeof(char));
   printf("Enter string:");
   scanf("%s",str);
   printf("%s",str);
   return 0;
}
 
