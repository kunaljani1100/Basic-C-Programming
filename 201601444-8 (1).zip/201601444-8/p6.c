#include<stdio.h>
void multiply(int a[5][4],int b[4][6],int m,int n,int o,int p)
{  int c[5][6],i,j,k=0;
   for(i=0;i<5;i++)
   {  for(j=0;j<6;j++)
      {  c[i][j]=0;
      }
   }
   for(j=0;j<6;j++)
   {  k=0;
      for(i=0;i<5;i++)
      {  c[i][j]= c[i][j]+a[i][k]+b[k][j];
      }
      k++;
   }
   for(i=0;i<5;i++)
   {  for(j=0;j<6;j++)
      {  printf("%d ",c[i][j]);
      }
      printf("\n");
   }
}
int main()
{  int a[5][4],b[4][6],i,j;
   printf("Enter matrix A:");  
   for(i=0;i<5;i++)
   {  for(j=0;j<4;j++)
      {  scanf("%d",&a[i][j]);
      }
   }
   printf("Enter matrix B:");
   for(i=0;i<4;i++)
   {  for(j=0;j<6;j++)
      {  scanf("%d",&b[i][j]);
      }
   }
   multiply(a,b,5,4,4,6);
   return 0;
}
