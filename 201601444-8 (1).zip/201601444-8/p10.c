#include<stdio.h>
int sum(int a,int b)
{  int c;
   c=a+b;
   return c;
}
int summ(int a, int b)
{  int c;
   c=a+b;
   return c;
}
int main()
{  int w,x,y,z,o,*p;
   printf("Enter first 2 values:"); 
   scanf("%d%d",&w,&x);
   printf("Enter next 2 values:");
   scanf("%d%d",&y,&z);
   o=sum(w,x);
   p=&o;
   printf("%d\n",*p);
   printf("%d\n",summ(y,z));
   return 0;
}
   
