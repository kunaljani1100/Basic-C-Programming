#include<stdio.h>
int add(int a,int b)
{  int c;
   c=a+b;
   return c;
}
int sub(int a,int b)
{  int c;
   c=a-b;
   return c;
}
int mult(int a,int b)
{  int c;
   c=a*b;
   return c;
}
int main()
{  int *p[3],ary[3];
   int a,b,ch;
   printf("0.Add\n1.Subtract\n2.Multiply\n");
   scanf("%d",&ch);
   printf("Enter 2 nos:");
   scanf("%d%d",&a,&b);
   ary[0]=add(a,b);
   ary[1]=sub(a,b);
   ary[2]=mult(a,b);
   p[0]=&ary[0];
   p[1]=&ary[1];
   p[2]=&ary[2];
   printf("%d",*(p[ch]));
   return 0;
}

