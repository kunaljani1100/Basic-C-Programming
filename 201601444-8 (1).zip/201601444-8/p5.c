#include<stdio.h>
void printres(int s1,int s2,int s3)
{  int perc,total;
   total=s1+s2+s3;
   perc=(s1+s2+s3)/3;
   printf("Total:%d\n",total);
   printf("Percentage:%d",perc);
}
int main()
{  int sub1,sub2,sub3;
   printf("Enter marks in 3 subjects:");
   scanf("%d%d%d",&sub1,&sub2,&sub3);
   printres(sub1,sub2,sub3);
   return 0;
}
