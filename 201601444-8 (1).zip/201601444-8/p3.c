#include<stdio.h>
#include<string.h>
void arrange(char str[5][20],int size)
{  char tmp[100];
   int i,j,a;
   for(a=0;a<5;a++){
   for(i=0;i<4;i++)
   {  for(j=0;str[i][j]!='\0';j++)
      {  if(str[i][j]>str[i+1][j])
         {  strcpy(tmp,str[i]);
            strcpy(str[i],str[i+1]);
            strcpy(str[i+1],tmp);
            break;
         }
      }
   }}
}
int main()
{  char name[5][20];
   int i;
   printf("Enter 5 names:");
   for(i=0;i<5;i++)
   {  scanf("%s",name[i]);
   }
   arrange(name,5);
   for(i=0;i<5;i++)
   {  printf("%s\n",name[i]);
   }
   return 0;
}
 
