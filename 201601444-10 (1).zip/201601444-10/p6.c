#include<stdio.h>
#include<stdlib.h>
int main()
struct employee
{  int no;
   char name[20];
   char sex;
   float salary;
}e;
int main()
{  FILE *fp;
   fp=fopen("e.c","r+");
   int choice=1;
   while(choice==1)
   {  printf("Enter number:");
      scanf("%d",&e.no);
      printf("Enter name:");
      scanf("%s",e.name);
      printf("Enter sex:");
      scanf("%s",&e.sex);
      printf("Enter salary:");
      scanf("%f",&e.salary);
      printf("Want to enter more?(0/1)");
      fread(&e,sizeof(e),1,pf);
      scanf("%d",&choice);
      if(choice==0)
      break;
   }
   int num;
   printf("Enter employee no:");
   scanf("%d",&num);
   while(fread(&e,sizeof(e),1,fp)==1)
   {  if(num==e.no)
      {  printf("Number:%d",e.no);
         printf("\nName:"):
         printf("%s",e.name):
         printf("\nSex:");
         printf("%c",e.sex);
         printf("\nSalary:");
         printf("%f",e.salary);
      }
   }
   printf("Enter number of employee for whom you want to increase the salary:");
   scanf("%d",&num);
   while(fread(&e,sizeof(e),1,fp)==1)
   {  if(num==e.no)
      {  printf("Enter new salary:");
         scanf("%d",e.salary);
      }
   }
   fclose(fp);
   return 0;
}
