#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{  FILE *fp,*fo;
   fp=fopen("tx1.c","r+");
   fo=fopen("tx2.c","r+");
   char str[100];
   char ch;
   int i=0;
   int j;
   while(1)
   {  if(ch==EOF)
      {  str[i]='\0';
         break;
      }
      ch=fgetc(fp);
      str[i++];
   }
   for(i=0;str[i+5]!='\0';i++)
   {  if(str[i]==' '&&str[i+1]=='a'&&str[i+2]==' ')
      {  str[i+1]=' ';
         for(j=i;str[j]!='\0';j++)
         {  str[i]=str[i+1];
         }
      }
      if(str[i]==' '&&str[i+1]=='a'&&str[i+2]=='n'&&str[i+3]=='d'&&str[i+4]==' ')
      {  str[i+1]=' ';
         str[i+2]=' ';
         str[i+3]=' ';
         for(j=i;str[j]!='\0';j++)
         {  str[i]=str[i+3];
         }

      }
      if(str[i]==' '&&str[i+1]=='t'&&str[i+2]=='h'&&str[i+3]=='e'&&str[i+4]==' ')
      {  str[i+1]=' ';
         str[i+2]=' ';
         str[i+3]=' ';
         for(j=i;str[j]!='\0';j++)
         {  str[i]=str[i+3];
         }

      }
   }
   i=0;
   while(str[i]!='\0')
   {  fputc(str[i],fo);
      i++;
   }
   fclose(fp);
   fclose(fo);
   return 0;
}
