#include<stdio.h>
int main()
{  FILE *fp;
   int ch;
   fp=fopen("trial.txt","r+");
   int wcnt=0;
   int cnt=0;
   while(1)
   {  ch=fgetc(fp);
      if(ch==EOF)
      break;
      if(ch=='\n'||ch=='.'||ch==' '||ch==',')
      {  wcnt=0;
         if(wcnt==4)
         cnt++;
      }
      else
      {  wcnt++;}
   }
   printf("No of words=%d",cnt);
   return 0;
}
   
