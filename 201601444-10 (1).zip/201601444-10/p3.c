#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct student
{  char name[20];
   int age;
}s;
int main()
{  FILE *fp,*fo;
   fp=fopen("str.c","r+");
   int i=1;
   while(i!=0)
   { 
      printf("Enter name:");
      scanf("%s",s.name);
      printf("Enter age:");
      scanf("%d",&s.age);
      fwrite(&s,sizeof(s),1,fp);
      printf("Want to enter(0/1):");
      scanf("%d",&i);
      if(i==0)
      break;
   }
   fclose(fp);
   fo=fopen("str.c","r+");
   while(fread(&s,sizeof(s),1,fo)==1)
   printf("%s %d\n",s.name,s.age);
   fclose(fo);
   return 0;
}
   

