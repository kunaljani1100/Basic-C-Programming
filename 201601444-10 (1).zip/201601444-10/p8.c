#include<stdio.h>
int main()
{  FILE *fp;
   int ch;
   int i=0;
   char word[20];
   fp=fopen("trial.txt","r+");
   int wcnt=0;
   int cnt=0;
   while(1)
   {  ch=fgetc(fp);
      if(ch==EOF)
      break;
      if(ch=='\n'||ch=='.'||ch==' '||ch==',')
      {  while(i>=0)
         {  printf("%c",word[i]);
            i--;
         }
         i=0;
         printf(" ");
      }
      else
      {  word[i]=ch;
         i++;
      }
   }
   printf("No of words=%d",cnt);
   return 0;
}
