#include<stdio.h>
int main()
{  FILE *fp;
   int i=0;
   char ch;
   fp=fopen("kj.c","r");
   while(1)
   {  ch=fgetc(fp);
      printf("%c",ch);
      if(ch=='\n')
      {  i++;
         printf("Line %d\n",i);
      }
      if(ch==EOF)
      break;
   }
   printf("\n");
   fclose(fp);
   return 0;
}
