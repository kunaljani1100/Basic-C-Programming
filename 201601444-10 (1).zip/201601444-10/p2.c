#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{  FILE *fp,*fo;
   char ch;
   char str[100];
   fp=fopen("kj.c","r+");
   fo=fopen("kj1.c","r+");
   while(1)
   {  ch=fgetc(fp);
      fputc(ch,fo);
      if(ch==EOF)
      break;
   }
   fclose(fp);
   fclose(fo);
   return 0;
}
   
