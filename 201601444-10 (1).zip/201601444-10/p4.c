#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{  FILE *fi,*fo;
   char ch;
   fi=fopen("f1.c","r+");
   fo=fopen("f2.c","r+");
   while(1)
   {  
      ch=fgetc(fi);
      fputc(ch,fo);
      if(ch==EOF)
      break;
   }
   fclose(fi);
   fclose(fo);
   return 0;
}  
