#include<stdio.h>
int main()
{  int d5,a,b,c,d,e;
   printf("Enter a 5 digit number:\n");
   scanf("%d",&d5);
   a=d5%10;
   b=(d5%100-a)/10;
   c=(d5%1000-a)/100;
   d=(d5%10000-a)/1000;
   e=(d5%100000-a)/10000;
   a=a-1;
   b=b-1;
   c=c-1;
   d=d-1;
   e=e-1;
   printf("%d%d%d%d%d",e,d,c,b,a);
   return 0;
}
   
