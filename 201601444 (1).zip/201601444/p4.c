#include<stdio.h>
int main()
{  int digit4,a,b,c,d,sum;
   printf("Enter a 4 digit number:");
   scanf("%d",&digit4);
   a=digit4%10;
   b=(digit4%100-a)/10;
   c=(digit4%1000-b)/100;
   d=(digit4%10000-c)/1000;
   sum=a+b+c+d;
   printf("Sum of digits=%d",sum);
   return 0;
}
