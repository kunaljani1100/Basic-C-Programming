#include<stdio.h>
int main()
{  float r,d,area,cir;
   printf("\nEnter radius:");
   scanf("%f",&r);
   d=2*r;
   area=3.14159*r*r;
   cir=2*3.14159*r;
   printf("\nDiameter=%f",d);
   printf("\nArea=%f",area);
   printf("\nCircumference=%f",cir);
   return 0;
}

 
