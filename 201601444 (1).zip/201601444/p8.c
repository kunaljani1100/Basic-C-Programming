#include<stdio.h>
int main()
{  int d5,a,b,c,d,e;
   printf("\nEnter a 5 digit number:");
   scanf("%d",&d5);
   a=d5%10;
   b=(d5%100-a)/10;
   c=(d5%1000-a)/100;
   d=(d5%10000-a)/1000;
   e=(d5%100000-a)/10000;
   printf("Digits:");
   printf("%d   %d   %d   %d   %d\n",e,d,c,b,a);
   return 0;
}

