#include<stdio.h>
int main()
{  float basic,rent,all,gross;
   printf("\nEnter basic salary.\n");
   scanf("%f",&basic);
   rent=0.4*basic;
   gross=0.2*basic;
   gross=basic+rent+all;
   printf("\nGross salary=%f\n",gross);
   return 0;
}
   

