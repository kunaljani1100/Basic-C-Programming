#include<stdio.h>
int main()
{  float tsp,profit,cp;
   printf("\nEnter total selling price for 15 items:");
   scanf("%f",&tsp);
   printf("\nEnter total profit:");
   scanf("%f",&profit);
   cp=(tsp-profit)/15;
   printf("\nCost price of 1 item=%f",cp);
   return 0;
}

