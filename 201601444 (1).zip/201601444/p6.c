#include<stdio.h>
int main()
{  int n1,n2;
   printf("Enter 2 numbers:");
   scanf("%d%d",&n1,&n2);
   printf("\nSum=%d",n1+n2);
   printf("\nDifference=%d",n1-n2);
   printf("\nProduct=%d",n1*n2);
   printf("\nQuotient=%d",n1/n2);
   printf("\nRemainder=%d",n1%n2);
   return 0;
}

