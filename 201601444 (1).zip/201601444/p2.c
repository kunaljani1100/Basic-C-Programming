#include<stdio.h>
int main()
{
float km,f,m,in,cm;
printf("enter distance(in km):");
scanf("%f",&km);
f=km*3280.84;
m=km*1000;
in=km*39370.1;
cm=m*1000;
printf("feet= %f",f);
printf("\n meters= %f",m);
printf("\n inches= %f",in);
printf("\n centimeters= %f",cm);
return 0;
}


