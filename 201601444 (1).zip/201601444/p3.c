#include<stdio.h>
int main()
{
float a,b,c,d,e,total;
float per;
printf("enter marks out of 100:");
scanf("%f%f%f%f%f",&a,&b,&c,&d,&e);
total=a+b+c+d+e;
per=total/5.0;
printf("total=%f\n percentage=%f",total,per);
return 0;
}

