#include<stdio.h>
int main()
{  int s1,s2,hyp[501],i,j;
   for(i=1;i<=500;i++)
   {  hyp[i]=i;}
   for(s1=1;s1<=500;s1++)
   {  for(s2=1;s2<=500;s2++)
      {  for(i=1;i<=501;i++)
         if(hyp[i]*hyp[i]==s1*s1+s2*s2)
         {  for(j=0;j<i;j++)
            {if(hyp[i]==hyp[j])
            break;}
         if(i==j)
         printf("%d %d %d\n",s1,s2,hyp[i]);}
      } 
   }
   return 0;         
}
