#include<stdio.h>
int main()
{  int a[76],pop[76],inc,j=1;
   int i;
   for(i=1;i<=75;i++)
   {  a[i]=j;
      j=j+1;
   }
   pop[1]=70000;
   for(i=2;i<=75;i++)
   {  pop[i]=pop[i-1]+((5*pop[i-1])/100);
   }
   printf("%d\t%d\t%d\n",a[1],pop[1],0);
   for(i=2;i<=75;i++)
   {  printf("%d\t%d\t%d\n",a[i],pop[i],pop[i]-pop[i-1]);
   }
   for(i=2;i<75;i++)
   {  if(pop[i]>=2*pop[1])
      break;
   }
   printf("Population doubles in %d th year.",i);
   return 0;
}
