#include<stdio.h>
int main()
{  float acno,bal,totitem,totcredit,lim;
   do{
   printf("Account no:");
   scanf("%f",&acno);
   if(acno==-1)
   break;
   printf("Balance:");
   scanf("%f",&bal);
   printf("Total items:");
   scanf("%f",&totitem);
   printf("Total credits:");
   scanf("%f",&totcredit);
   printf("Limit:");
   scanf("%f",&lim);
   bal=bal+totcredit;
   printf("\nAccount:%f",acno);
   printf("\nBalance:%f",bal);
   printf("\nLimit:%f",lim);
   if(lim<bal)
   {  printf("Balance exceeded.");
   }
   else
   {  printf("Balance not exceeded.");
   }
   printf("\n");
}while(acno!=-1);
   return 0;
}
