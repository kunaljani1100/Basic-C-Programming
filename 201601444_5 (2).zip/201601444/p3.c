#include<stdio.h>
int main()
{  int a[]={1,2,3,4,5,6,7,8,9,10};
   int ele,beg=0,last=9,mid,flag=0;
   printf("Enter the element to be searched for:");
   scanf("%d",&ele);
   while(beg!=last)
   {  mid=(beg+last)/2;
      if(a[mid]<ele)
        beg=mid+1;
      else if(a[mid]>ele)
        last=mid-1;
      else
      { flag=1;
        break; 
      }
      if(beg==last)
        break;
   }
   if(flag==1)
   {  printf("Element found");
   }
   else
   {  printf("Element not found");
   }
   return 0;
}

