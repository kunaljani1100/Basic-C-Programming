#include<stdio.h>
int main()
{  int bin,dec,a,b,c,d,e;
   printf("Enter binary number with 5 digits or less:");
   scanf("%d",&bin);
   a=bin%10;
   b=(bin%100-a)/10;
   c=(bin%1000-b)/100;
   d=(bin%10000-c)/1000;
   e=(bin%100000-d)/10000;
   dec=(16*e)+(8*d)+(4*c)+(2*b)+a;
   printf("Decimal:%d",dec);
   return 0;
}
      
