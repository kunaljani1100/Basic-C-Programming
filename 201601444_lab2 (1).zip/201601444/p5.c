#include<stdio.h>
int main()
{  int d4,a,b,c,d,rev;
   printf("Enter a 4 digit number:");
   scanf("%d",&d4);
   a=d4%10;
   b=(d4%100-a)/10;
   c=(d4%1000-a)/100;
   d=(d4%10000-a)/1000;
   rev=1000*a+100*b+10*c+d;
   if(rev==d4)
     printf("It is palindrome\n");
   else
     printf("It is not palindrome\n");
   return 0;
}

