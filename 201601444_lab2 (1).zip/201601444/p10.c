#include<stdio.h>
int main()
{  char ch;
   printf("Enter a character:");
   scanf("%c",&ch);
   if((ch>=0&&ch<=47)||(ch>=58&&ch<=64)||(ch>=91&&ch<=96)||(ch>=123&&ch<=127))
   printf("\nSpecial character.");
   else 
   printf("\nNot a special character.");
   if(ch>='0'&&ch<='9')
   printf("\nNumber.");
   else
   printf("\nNot a number.");
   return 0;
}
