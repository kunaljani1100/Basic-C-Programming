#include<stdio.h>
int main()
{  float l,b,area,per,dif;
   printf("Enter length:");
   scanf("%f",&l);
   printf("Enter breadth:");
   scanf("%f",&b);
   area=l*b;
   per=2*(l+b);
   dif=area-per;
   printf("\nArea=%f",area);
   printf("\nPerimeter=%f",per);
   printf("\nDifference=%f",dif);
   return 0;
}
   
