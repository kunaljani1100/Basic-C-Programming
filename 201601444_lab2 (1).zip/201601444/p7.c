#include<stdio.h>
int main()
{ int no;
  printf("Enter an integer:\n");
  scanf("%d",&no);
  if(no%13==0)
    printf("It is a multiple of 13\n");
  else
    printf("It is not a multiple of 13\n");
  return 0;
} 
