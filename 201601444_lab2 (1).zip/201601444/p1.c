#include<stdio.h>
int main()
{  int stid,days,fine;
   printf("Student id");
   scanf("%d",&stid);
   printf("Enter no of days by which submission has been late:\n");
   scanf("%d",&days);
   if(days<=4)
   { fine=1*days;
     printf("Fine=%d",fine);
   } 
   else if(days>=5&&days<=8)
   { fine=3*days;
     printf("Fine=%d",fine);
   }
   else if(days>=9&&days<=12)
   { fine=5*days;
     printf("Fine=%d",fine);
   }
   else if(days>=12&&days<=30)
   { fine=7*days;
     printf("Fine=%d",fine);
   }
   else
   {  printf("Membership is cancelled.");}
   return 0;
}
