#include<stdio.h>
int main()
{  int a,b,c,product;
   printf("Enter 3 different numbers:");
   scanf("%d%d%d",&a,&b,&c);
   if(a>b&&a>c)
   {  printf("Largest=%d\n",a);
      if(b>c)
        product=a*c;
      else 
        product=a*b;
   }
   if(b>a&&b>c)
   {  printf("Largest=%d\n",b);
      if(c>a)
        product=b*a;
      else
        product=c*b;
   }
   if(c>a&&c>b)
   {  printf("Largest=%d\n",c);
      if(b>a)
        product=a*c;
      else
        product=c*b;
   }
   if(a>c&&b>c)
      printf("Smallest=%d\n",c); 
   if(a>b&&c>b)
      printf("Smallest=%d\n",b);
   if(c>a&&b>a)
      printf("Smallest=%d\n",a);
   printf("Product=%d\n",product);
   return 0;
}
