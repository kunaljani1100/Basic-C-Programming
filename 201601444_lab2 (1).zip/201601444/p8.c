#include<stdio.h>
int main()
{  int y1,y2,y3;
   printf("Enter 3 years:\n");
   scanf("%d%d%d",&y1,&y2,&y3);
   printf("Leap year:");
   if(y1%4==0)
   {  printf("%d ",y1);}
   if(y2%4==0)
   {  printf("%d ",y2);}
   if(y3%4==0)
   {  printf("%d ",y3);}
   printf("\nNot a leap year:");
   if(y1%4!=0)
   {  printf("%d ",y1);}
   if(y2%4!=0)
   {  printf("%d ",y2);}
   if(y3%4!=0)
   {  printf("%d ",y3);}
   return 0;
}

   

