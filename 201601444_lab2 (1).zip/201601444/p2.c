#include<stdio.h>
int main()
{  int d5,a,b,c,d,e,rev,x;
   printf("Enter a 5 digit number:\n");
   scanf("%d",&d5);
   a=(d5%10);
   b=(d5%100-a)/10;
   c=(d5%1000-b)/100;
   d=(d5%10000-c)/1000;
   e=(d5%100000-c)/10000;
   rev=10000*a+1000*b+100*c+10*d+e;
   printf("Reversed number=%d\n",rev);
   x=99999-rev;
   printf("x=%d (99999-%d=%d)",x,rev,x);
   return 0;
}
