#include<stdio.h>
int main()
{  char ch;
   int c;
   printf("Enter any character:\n");
   scanf("%c",&ch);
   c=ch;
   if(ch>='A'&&ch<='Z')
   {  printf("Capital letter ");}
   else if(ch>='a'&&ch<='z')
   {  printf("Small letter ");}
   else if(ch>='0'&&ch<='9')
   {  printf("Digit ");}
   else 
   {  printf("Special symbol ");}
   printf("with Ascii equivalent of %d\n",c);
   ch=ch+1;
   c=c+1;
   printf("The next character is %c with Ascii equivalent of %d\n",ch,c);
   return 0;
}
   
