#include<stdio.h>
int main()
{  int year,day=0,i=1900;
   printf("Enter any year:\n");
   scanf("%d",&year);
   if(year>=1900)
   {  while(i>year)
      {  
         if(year%4==0)
         {  if(day==5)
            {  day=0;}
            else if(day==6)
            {  day=1;}
            else
            {  day=day+2;}
         }
         else
         {
            if(day==6)
            {  day=0;}
            else
            {  day++;}
         }
      i--;
      }
   } 
   else
   {  while(i>year)
      {  if(year%4==0)
         {  if(day==0)
            {  day=5;}
            else if(day==1)
            {  day=6;}
            else
            {  day=day-2;}
         }
         else{
            if(day==0)
            {  day=6;}
            else
            {  day--;}
         }
         i--;
      } 
   }
   if(day==0)
   {  printf("Wednesday");}
   else if(day==1)
   {  printf("Thursday");}
    else if(day==2)
   {  printf("Friday");}
    else if(day==3)
   {  printf("Saturday");}
    else if(day==4)
   {  printf("Sunday");}
    else if(day==5)
   {  printf("Monday");}
   else
   {  printf("Tuesday");}
   return 0;
}            
   

