#include<stdio.h>
void marks(float s1,float s2,float s3)
{  float avg,perc;
   avg=(s1+s2+s3)/3;
   perc=avg;
   printf("Average=%f\n",avg);
   printf("Percentage=%f\n",perc);
}
int main()
{  float subj1,subj2,subj3;
   printf("Enter marks in 3 subjects:");
   scanf("%f%f%f",&subj1,&subj2,&subj3);
   marks(subj1,subj2,subj3);
   return 0;
}
