#include<stdio.h>
void calc(int num1,int num2,int num3,int num4,int num5)
{  int sum,avg,sd,x1,x2,x3,x4,x5,var;
   sum=num1+num2+num3+num4+num5;
   avg=sum/5;
   if(num1-avg<0)
   {  x1=avg-num1;}
   else
   {  x1=num1-avg;}
   if(num2-avg<0)
   {  x2=avg-num2;}
   else
   {  x2=num2-avg;}
   if(num3-avg<0)
   {  x3=avg-num3;}
   else
   {  x3=num3-avg;}
   if(num4-avg<0)
   {  x4=avg-num4;}
   else
   {  x4=num4-avg;}
   if(num5-avg<0)
   {  x5=avg-num5;}
   else
   {  x5=num5-avg;}
   var=((x1*x1)+(x2*x2)+(x3*x3)+(x4*x4)+(x5*x5))/5;
   for(sd=0;sd*sd<var;sd++);
   printf("Sum=%d\n",sum);
   printf("Average=%d\n",avg);
   printf("Standard deviation=%d\n",sd);
}
int main()
{  int d1,d2,d3,d4,d5;
   printf("Enter 5 integers:");
   scanf("%d%d%d%d%d",&d1,&d2,&d3,&d4,&d5);
   calc(d1,d2,d3,d4,d5);
   return 0;
}
