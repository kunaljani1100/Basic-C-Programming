#include<stdio.h>
int flor(float a)
{  int b;
   b=a;
   return b;
}
int main()
{  float x,y;
   while(x!=0)
   {  printf("Enter the value of x (0 to exit):");
      scanf("%f",&x);
      if(x==0)
         break;
      y=flor(x+0.5);
      printf("%f %f",x,y);
   }
   return 0;
}
