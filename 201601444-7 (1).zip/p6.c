#include<stdio.h>
void sort(int a[],int size)
{  int tmp,j,i;
   for(i=0;i<size;i++)
   {  for(j=0;j<size-1;j++)
      {  if(a[j]>a[j+1])
         {  tmp=a[j];
            a[j]=a[j+1];
            a[j+1]=tmp;
         }
      }
   }
   for(i=0;i<size;i++)
   {  printf("%d ",a[i]);
   }
}
int main()
{  int ary[5],i;
   printf("Enter the 5 elements:");
   for(i=0;i<5;i++)
   {  scanf("%d",&ary[i]);
   }
   sort(ary,5);
   return 0;
}
