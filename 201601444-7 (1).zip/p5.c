#include<stdio.h>
void digit(int x)
{  int a,b,c,d,e,sum,sumx=0;
   a=x%10;
   b=(x%100-a)/10;
   c=(x%1000-b)/100;
   d=(x%10000-c)/1000;
   e=(x%100000-c)/10000;
   sum=a+b+c+d+e;
   while(x!=0)
   {  a=x%10;
      sumx=sumx+a;
      x=x/10;
   }
   printf("Sum without recursion=%d\n",sum);
   printf("Sum with recursion=%d",sumx);
}
int main()
{  int num;
   printf("Enter a 5 digit number:");
   scanf("%d",&num);
   digit(num);
   return 0;
}
