#include<stdio.h>
int main()
{  static int count=1;
   printf("%d ",count);
   count++;
   main();
}
