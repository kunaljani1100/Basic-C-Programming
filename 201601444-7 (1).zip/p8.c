#include<stdio.h>
int strrlen(char s[])
{  int i;
   for(i=0;s[i]!='\0';i++);
   return i;
}
int check(char s1[],char s2[])
{  int flag=1,i;
   if(strrlen(s1)!=strrlen(s2))
   {  flag=0;
   }
   else
   {  for(i=0;s1[i]!='\0';i++)
      if(s1[i]!=s2[i])
      flag=0;
   }
   return flag;
}
void concat(char s1[],char s2[])
{  char s3[130],i,j;
   for(i=0;s1[i]!='\0';i++)
   {  s3[i]=s1[i];
   }
   for(j=0;s2[j]!='\0';j++)
   {  s3[i]=s2[j];
      i++;
   }
   s3[i]='\0';
   printf("%s",s3);
}
void rev(char s[])
{  int i,len;
   char tmp;
   len=strrlen(s);
   len=len-1;
   for(i=0;i<len/2;i++)
   {  tmp=s[i];
      s[i]=s[len-i];
      s[len-i]=tmp;
   }
   printf("%s",s);
}
int main()
{  int choice;
   char str[50],strx[50];
   while(choice!=5){
   printf("Enter your choice:\n");
   printf("1.String length\n");
   printf("2.Check equality\n");
   printf("3.Concatenate\n");
   printf("4.Reverse\n");
   printf("5.Exit\n");
   scanf("%d",&choice);
   if(choice==5)
   {  break;}
   printf("Enter string:");
   scanf("%s",str);
   switch(choice)
   {  case 1:
        printf("Length=%d",strrlen(str));
        break;
      case 2:
        printf("Enter the new string:");
        scanf("%s",strx);
        if(check(str,strx)==0)
        {  printf("Strings are not same");
        }
        else
        {  printf("Strings are the same");
        }
        break;
      case 3:
        printf("Enter the other string:");
        scanf("%s",strx);
        concat(str,strx);
        break;
      case 4:
        rev(str);
        break;
      case 5:
        break;
    }}
    return 0;
}
