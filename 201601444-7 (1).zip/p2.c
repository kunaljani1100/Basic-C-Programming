#include<stdio.h>
int main()
{  int num,i,kj=1,j,a;
   printf("Enter the number:");
   scanf("%d",&num);
   a=num;
   for(i=2;i<a;i++)
   {  for(j=2;j<i;j++)
      {  if(i%j==0)
         kj=0;
      }
      if(kj==1)
      {  while(num%i==0)
         {  num=num/i;
            printf("%d,",i);
         }
      }
      kj=1;
   }
   return 0;
}
