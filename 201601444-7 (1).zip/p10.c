#include<stdio.h>
int main()
{  int a[1001],b[1001],i,sum,j;
   for(i=1;i<=1000;i++)
   {  a[i]=i;
   }
   for(i=1;i<=1000;i++)
   {  b[i]=0;
   }
   for(i=1;i<=1000;i++)
   {  for(j=1;j<i;j++)
      if(i%j==0)
      {  b[j]=1;}
      for(j=1;j<i;j++)
      {  if(b[j]==1)
         sum=sum+j;
      }
      if(sum==i)
      {  printf("%d ",i);}
      sum=0;
      for(j=1;j<=1000;j++)
      {  b[j]=0;
      }
   }
   return 0;
}
      
