#include<stdio.h>
void sort(int a[],int size)
{  int tmp,j,i;
   for(i=0;i<size;i++)
   {  for(j=0;j<size-1;j++)
      {  if(a[j]>a[j+1])
         {  tmp=a[j];
            a[j]=a[j+1];
            a[j+1]=tmp;
         }
      }
   }
   for(i=0;i<size;i++)
   {  printf("%d ",a[i]);
   }
}
void sumup(int a[],int size)
{  int sum=0,i;
   for(i=0;i<size;i++)
   {  sum=sum+a[i];
   }
   printf("Sum=%d",sum);
}
void rev(int a[],int size)
{  int tmp,i,j;
   for(i=0;i<size/2;i++)
   {  tmp=a[i];
      a[i]=a[size-1-i];
      a[size-1-i]=tmp;
   }
   for(i=0;i<size;i++)
   {  printf("%d ",a[i]);
   }
}
void search(int a[],int size,int ele)
{  int k=0,i;
   for(i=0;i<size;i++)
   {  if(a[i]==ele)
      k=1;
   }
   if(k==1)
   {  printf("Element found.");
   }
   else
   {  printf("Element not found.");
   }
}
int main()
{  int choice,ary[6],i,element;
   while(choice!=5){
   printf("Enter your choice:\n");
   printf("1.Sort\n");
   printf("2.Sum up\n");
   printf("3.Reverse\n");
   printf("4.Search\n");
   printf("5.Exit\n");
   scanf("%d",&choice);
   if(choice==5)
     break;
   printf("Enter the array:");
   for(i=0;i<6;i++)
   {  scanf("%d",&ary[i]);
   }
   switch(choice)
   {  case 1:
        sort(ary,6);
        break;
      case 2:
        sumup(ary,6);
        break;
      case 3:
        rev(ary,6);
        break;
      case 4:
        printf("Enter element:");
        scanf("%d",&element);
        search(ary,6,element);
        break;
      case 5:
        break;
    }
    if(choice==5)
    break;
    }
    return 0;
}
