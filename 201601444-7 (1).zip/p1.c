#include<stdio.h>
int main()
{  int num,a,i=0,j;
   char str[100];
   printf("Enter any year:");
   scanf("%d",&num);
   a=num/1000;
   for(j=0;j<a;j++)
   {  str[i]='m';
      i++;
   }
   num=num%1000;
   a=num/500;
   for(j=0;j<a;j++)
   {  str[i]='d';
      i++;
   }
   num=num%500;
   a=num/100;
   for(j=0;j<a;j++)
   {  str[i]='c';
      i++;
   }
   num=num%100;
   a=num/50;
   for(j=0;j<a;j++)
   {  str[i]='l';
      i++;
   }
   num=num%50;
   a=num/10;
   for(j=0;j<a;j++)
   {  str[i]='x';
      i++;
   }
   num=num%10;
   a=num/5;
   for(j=0;j<a;j++)
   {  str[i]='v';
      i++;
   }
   num=num%5;
   a=num/1;
   for(j=0;j<a;j++)
   {  str[i]='i';
      i++;
   }
   str[i]='\0';
   printf("%s",str);
   return 0;
}

