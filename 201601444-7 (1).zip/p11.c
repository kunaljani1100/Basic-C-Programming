#include<stdio.h>
int max(int a[],int size)
{  int m,i;
   a[0]=m;
   for(i=1;i<size;i++)
   {  if(a[i]>m)
      m=a[i];
   }
   return m;
}
int main()
{  int ary[10],i;
   printf("Enter an array:");
   for(i=0;i<10;i++)
   {  scanf("%d",&ary[i]);
   }
   printf("Biggest number=%d",max(ary,10));
   return 0;
}
